`timescale 1ns / 1ps
module tb_pc;
    reg [15:0] in;
    reg load, inc, reset, clk;
    wire [15:0] out;

    pc uut (.in(in), .load(load), .inc(inc), .reset(reset), .clk(clk), .out(out));

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        $display("Time | R L I | In    | Out");
        $monitor("%4t | %b %b %b | %5d | %5d", $time, reset, load, inc, in, out);

        in=0; load=0; inc=0; reset=0; #10;

        in=999; load=1; reset=1; #10;
        reset=0; #10;

        in=55; load=1; #10;
        load=0; #10;

        inc=1; #30; 
        
        in=100; load=1; inc=1; #10; 

        $finish;
    end
endmodule