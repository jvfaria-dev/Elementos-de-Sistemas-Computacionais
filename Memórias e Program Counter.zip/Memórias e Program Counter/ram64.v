module ram64 (
    input [15:0] in,
    input load,
    input [5:0] address,
    input clk,
    output [15:0] out
);
    reg [15:0] mem [0:63];

    assign out = mem[address];

    always @(posedge clk) begin
        if (load) mem[address] <= in;
    end
endmodule