module ram8 (
    input [15:0] in,
    input load,
    input [2:0] address,
    input clk,
    output [15:0] out
);
    reg [15:0] mem [0:7];

    assign out = mem[address];

    always @(posedge clk) begin
        if (load) begin
            mem[address] <= in;
        end
    end
endmodule