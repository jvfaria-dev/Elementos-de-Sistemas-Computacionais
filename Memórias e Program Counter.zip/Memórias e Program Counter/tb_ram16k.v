`timescale 1ns / 1ps
module tb_ram8;
    reg [15:0] in;
    reg load, clk;
    reg [13:0] address;
    wire [15:0] out;

    ram8 uut (.in(in), .load(load), .address(address), .clk(clk), .out(out));

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        $monitor("Time=%0t | Addr=%d Load=%b In=%d | Out=%d", $time, address, load, in, out);
        
        address = 3; in = 555; load = 1; #10;
        load = 0;
        
        address = 7; in = 999; load = 1; #10;
        load = 0;

        address = 3; #10;
        
        address = 7; #10;
        
        address = 0; #10;

        $finish;
    end
endmodule