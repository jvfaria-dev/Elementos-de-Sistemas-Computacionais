module ram4k (
    input [15:0] in,
    input load,
    input [11:0] address,
    input clk,
    output [15:0] out
);
    reg [15:0] mem [0:4095];

    assign out = mem[address];

    always @(posedge clk) begin
        if (load) mem[address] <= in;
    end
endmodule