# Projeto de Memória RAM e Lógica Sequencial em Verilog

[cite_start]Este projeto implementa a hierarquia de memória e lógica sequencial para a construção de um computador, partindo de flip-flops elementares até bancos de memória RAM de grande porte e contadores de programa, baseado no **Projeto 3** do curso Nand2Tetris[cite: 1, 3].

## 📋 Conteúdo

### Lógica Sequencial Elementar
- [cite_start]**dff.v** - Data Flip-Flop (Primitiva básica de armazenamento) [cite: 7]
- [cite_start]**bit.v** - Registrador de 1 bit (DFF + Multiplexador) [cite: 8]
- [cite_start]**register.v** - Registrador de 16 bits [cite: 9]

### Memória RAM (Random Access Memory)
- [cite_start]**ram8.v** - Memória de 8 registros de 16 bits (3 bits de endereço) [cite: 10]
- [cite_start]**ram64.v** - Memória de 64 registros (6 bits de endereço) [cite: 11]
- [cite_start]**ram512.v** - Memória de 512 registros (9 bits de endereço) [cite: 12]
- [cite_start]**ram4k.v** - Memória de 4096 registros (12 bits de endereço) [cite: 13]
- [cite_start]**ram16k.v** - Memória de 16384 registros (14 bits de endereço) [cite: 14]

### Contadores
- [cite_start]**pc.v** - Contador de Programa (Program Counter) de 16 bits com flags de Reset, Load e Inc[cite: 15].

## 🧪 Test Benches

Cada componente possui um test bench correspondente com o prefixo `tb_`:
- `tb_bit.v`, `tb_register.v`, `tb_ram8.v`, `tb_pc.v`, etc.

Os test benches validam o comportamento síncrono de escrita e a leitura combinacional das memórias.

## 🛠️ Requisitos

- **Icarus Verilog** (iverilog) - Compilador Verilog
- **VVP** - Simulador Verilog (incluído com Icarus Verilog)

### Instalação

**Ubuntu/Debian:**
```bash
sudo apt-get install iverilog