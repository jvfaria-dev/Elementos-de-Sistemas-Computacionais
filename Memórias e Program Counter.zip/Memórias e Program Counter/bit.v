module bit (
    input in,
    input load,
    input clk,
    output out
);
    wire mux_out;
    assign mux_out = (load) ? in : out;
    
    dff d1 (
        .in(mux_out),
        .clk(clk),
        .out(out)
    );
endmodule