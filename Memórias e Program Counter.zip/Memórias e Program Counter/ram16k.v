module ram16k (
    input [15:0] in,
    input load,
    input [13:0] address,
    input clk,
    output [15:0] out
);
    reg [15:0] mem [0:16383];

    assign out = mem[address];

    always @(posedge clk) begin
        if (load) mem[address] <= in;
    end
endmodule