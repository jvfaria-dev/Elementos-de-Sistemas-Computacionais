module pc (
    input [15:0] in,
    input load,
    input inc,
    input reset,
    input clk,
    output reg [15:0] out
);
    always @(posedge clk) begin
        if (reset) begin
            out <= 16'b0;
        end else if (load) begin
            out <= in;
        end else if (inc) begin
            out <= out + 1'b1;
        end
    end
endmodule