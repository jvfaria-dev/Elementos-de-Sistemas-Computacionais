`timescale 1ns / 1ps
module tb_register;
    reg [15:0] in;
    reg load, clk;
    wire [15:0] out;

    register uut (.in(in), .load(load), .clk(clk), .out(out));

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        $monitor("Time=%0t | Load=%b In=%d | Out=%d", $time, load, in, out);
        in = 0; load = 0; #10;
        
        in = 12345; load = 1; #10; 
        load = 0; in = 0; #10;    
        
        in = 6789; load = 1; #10; 
        
        $finish;
    end
endmodule